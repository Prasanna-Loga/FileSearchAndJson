import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONAware;
import org.json.simple.JSONValue;


public class testing {
 public static void main(String[] args){
	 String s1="qwerty";
	 List<Integer> s=new ArrayList<Integer>();
	 s.add(3);
	 s.add(6);
	 s.add(9);
	 s.add(4);
	 s.add(6);
	 JSONArray jsonArray = new JSONArray();
	 
	 jsonArray.add(s);
	 System.out.println(JSONValue.toJSONString(s1));
//	 string s2 = s1 ;
	 
	 System.out.println(jsonArray);
	 
 }
}
