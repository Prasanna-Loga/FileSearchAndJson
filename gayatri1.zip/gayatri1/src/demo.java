
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
public class demo {
 public static void search(File file,Object name)
 {
  File[] list = file.listFiles();
  for (File fil : list)
            //while(i.hasNext())
             {
                            if (fil.isDirectory()){
                            	search(fil,name);
                           // System.out.println("Folder:"+fil);
                            }
                 if(fil.isFile())
                	 if(fil.getName().equals(name)) {
                  System.out.println("File Found "+fil.getName()+" in the path "+fil.getParent());
                  //Map m  = new TreeMap();
                  
                	 } 
}
 }
  public static void main(String args[]) throws IOException {
                  
                  
                 // File f = new File("C:\\users\\GA331852\\");
                // ArrayList<File> files = new ArrayList<File>(Arrays.asList(f.listFiles()));
                  File file1 = new File("C:\\users\\PR377171\\workspace");
                //search(file1,"sample1.java");
                  //Iterator i= files.iterator();
                  
                  
                  ArrayList<String> q = new ArrayList<String>();
                  FileInputStream file = new FileInputStream(new File("data1.xls"));
                HSSFWorkbook workbook = new HSSFWorkbook(file);
                HSSFSheet sheet = workbook.getSheetAt(0);
                Iterator<Row> rowIterator = sheet.iterator();
 
                while (rowIterator.hasNext()) 
                {                              
                      Row row = rowIterator.next();
                      Iterator<Cell> cellIterator = row.cellIterator();
                        while (cellIterator.hasNext()) 
                            {
                                    Cell cell = cellIterator.next();
                                            if(Cell.CELL_TYPE_STRING==1)
                                            {
                                                            //System.out.print(cell.getStringCellValue() + "\t");
                                                            //search(file1,cell.getStringCellValue());}
//                                                           
                                            				q.add(cell.getStringCellValue());}
                                                       
                                        
                                                
                                }
                                System.out.println(q);
                }
                
                Iterator i=q.iterator();
                while(i.hasNext()){
                	search(file1,i.next());
                }
 
                                
                    
  }
}
